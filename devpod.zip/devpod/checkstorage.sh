#!/bin/bash
lxc storage info  $1-devpod
