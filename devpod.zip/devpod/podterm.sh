#!/bin/bash
lxc exec  $1-devpod -- bash
