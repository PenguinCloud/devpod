#!/bin/bash
lxc rm  $1-devpod  -f
